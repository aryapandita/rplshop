<?php
// index.php - RPLShop router and dynamic homepage loader
$path_prefix = '';
$page_title = 'RPLShop - Game Top-Up, Gift Card & Voucher | Game Credits | Mobile Games';

require_once __DIR__ . '/includes/functions.php';

$extra_css = ['home-af890912ab.css', 'coupon-1ff5107c71.css'];

$request_path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$base_path = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');

if ($base_path !== '' && $base_path !== '/' && strpos($request_path, $base_path) === 0) {
    $request_path = substr($request_path, strlen($base_path));
}

$route = trim($request_path, '/');

if ($route === 'index.php') {
    $query = $_SERVER['QUERY_STRING'] ?? '';
    header('Location: index.html' . ($query !== '' ? '?' . $query : ''));
    exit;
}

if (!in_array($route, ['', 'index.html'], true)) {
    http_response_code(404);
    echo 'Halaman tidak ditemukan.';
    exit;
}

// Dynamic data for homepage sections.
$stmt = $pdo->query("SELECT p.*, pp.name as package_name, pp.price, pp.discount_percent, pp.id as package_id
                     FROM products p
                     JOIN product_packages pp ON p.id = pp.product_id
                     WHERE pp.discount_percent > 0
                     ORDER BY pp.discount_percent DESC
                     LIMIT 10");
$special_deals = $stmt->fetchAll();

$popular_games = get_products($pdo, 'game', null, 6);
$popular_cards = get_products($pdo, 'card', null, 6);
$popular_topups = get_products($pdo, 'direct-topup', null, 6);
$popular_recharges = get_products($pdo, 'mobile-recharge', null, 6);

$featured_ml = get_product_by_slug($pdo, 'mobile-legends-diamonds');
$featured_steam = get_product_by_slug($pdo, 'steam-wallet-code-idr');
$featured_razer = get_product_by_slug($pdo, 'razer-gold-idr');

include __DIR__ . '/index.html';
